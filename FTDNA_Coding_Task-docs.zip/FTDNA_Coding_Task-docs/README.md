# FTDNA_Coding_Task
C# FTDNA Coding Task

Please complete this task using ASP.Net Core, ASP.NET Web API 2, Angular 2, and Entity Framework.

We ask that you return compilable code, and if it requires more than just building in VS to please include instructions on steps required.
