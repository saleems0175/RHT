
if exists(SELECT name FROM sys.databases
WHERE name = 'FTDNA')
DROP DATABASE FTDNA

GO

CREATE DATABASE FTDNA;

GO

Use[FTDNA]

GO


if exists( select * from sys.tables where name = 'Users')
Drop Table Users

GO

Create Table Users(
	UserId Int not null,
	FirstName varchar(30),
	LastName varchar(30)
	Constraint PK_UserId Primary Key(UserId)
);

GO
if exists (select * from sys.tables where name='Status')
Drop Table [Status]

GO

Create Table [Status](
	StatusId int,
	Status varchar(30),
	Constraint PK_StatusId Primary Key(StatusId)
);

GO

if exists (select * from sys.tables where name='Samples')
Drop Table Samples

GO

Create Table Samples(
	SampleId int not null,
	Barcode varchar(30),
	CreatedAt datetime,
	CreatedBy int,
	StatusId int,
	Constraint PK_SampleId Primary Key(SampleId),
	Constraint FK_Users_Samples Foreign Key(CreatedBy) References Users(UserId),
	Constraint FK_Status_Samples Foreign Key(StatusId) References [Status](StatusId)
);

