﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Data.Models;

namespace Data.Repositories
{
    public interface IUserRepository
    {
        void LoadData();
        List<User> GetAllUsers();
    }
    public class UserRepository : BaseRepository, IUserRepository
    {
        public UserRepository() : base("Users.txt")
        {
        }

        public List<User> GetAllUsers()
        {
            return context.Users.ToList();
        }

        public override void LoadData()
        {
            if(!context.Users.Any())
            {
                var readCsv = File.ReadAllText(base.filePath);
                var records = readCsv.Split('\n');

                for(int i =0; i < records.Count(); i++)
                {
                    if (i != 0) //avoid the first record its  a description
                    {
                        var record = records[i].TrimEnd('\r');
                        var splitResults = record.Split(',');

                        if(splitResults.Count() == 3)
                        {
                            User user = new User
                            {
                                UserId = int.Parse(splitResults[0]),
                                FirstName = splitResults[1],
                                LastName = splitResults[2]
                            };

                            context.Users.Add(user);
                        }
                    }
                }

                base.context.SaveChanges();
            }
        }

    }
}
