﻿angular.module('ftdnaApp').service('ftdnaService', ['$http', function ($http) {

    function GetAllSamples()
    {
        $http.post('/Home/GeAllSamples');
    }

    this.GetAllSamples = function()
    {
       return $http.post('/Home/GetAllSamples');
    }

    this.GetSampleByUserNameSearch = function(userNameSearchString)
    {
        return $http.post('/Home/GetSampleByUserNameSearch/', { userNameSearchString: userNameSearchString });
    }

    this.GetSamplesByStatusSearch = function (statusSearch)
    {
        return $http.post('/Home/GetSamplesByStatusSearch', { statusDescription: statusSearch });
    }

    this.CreateSample = function(sampleObject)
    {
        return $http.post('/Home/CreateSample', { sample: sampleObject });
    }

   

}])