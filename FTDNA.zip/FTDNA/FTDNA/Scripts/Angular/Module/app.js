﻿var ftdnaApp = angular.module('ftdnaApp', []);
