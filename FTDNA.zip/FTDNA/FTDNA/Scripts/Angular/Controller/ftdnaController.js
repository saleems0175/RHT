﻿angular.module('ftdnaApp').controller('ftdnaController',['$scope', '$http', '$filter', 'ftdnaService', function($scope, $http, $filter,ftdnaService)
{
  
   
     $scope.Init = function ()
     {
         $scope.orderByValue = "Barcode";

         $scope.orderByDesc = false;

         $scope.userList = userListData;
         $scope.statusList = statusListData;

         $scope.showSampleTable = false;
         $scope.showUserNameSearch = false;
         $scope.showStatusSearch = false;
         $scope.showCreateSample = false;

         $scope.showErrorAlert = false;
         $scope.showSuccessAlert = false;

         $scope.SamplesList = [];

         $scope.UserNameSearchString = "";
         $scope.StatusSearch;

         $scope.SampleObject =
             {
                 SampleId: 0,
                 Barcode: "",
                 CreatedAt: null,
                 CreatedBy: 0,
                 StatusId: 0,
                 User: null,
                 Status: null
             }
     }

    //return all samples
    $scope.GetAllSamples = function()
    {
        ftdnaService.GetAllSamples().then(function (result) {
            $scope.SamplesList = result.data;

            $scope.showSampleTable = true;
            $scope.showUserNameSearch = false;
            $scope.showStatusSearch = false;
            $scope.showCreateSample = false;

            $scope.showErrorAlert = false;
            $scope.showSuccessAlert = false;

            ConvertDatesToDateObject();
        });
    }

    //get samples by user name search
    $scope.GetSampleByUserNameSearch = function()
    {
        ftdnaService.GetSampleByUserNameSearch($scope.UserNameSearchString).then(function (result) {
            $scope.SamplesList = result.data;

            $scope.showSampleTable = true;
            $scope.showStatusSearch = false;
            $scope.showCreateSample = false;

            ConvertDatesToDateObject();
  
        });

    }

    $scope.GetSamplesByStatusSearch = function ()
    {
        ftdnaService.GetSamplesByStatusSearch($scope.StatusSearch).then(function (result) {
            $scope.SamplesList = result.data;

            $scope.showSampleTable = true;
            ConvertDatesToDateObject();

        })
    }

    //unable to format the DateCreated properly...cannot figure out why its not working
    function ConvertDatesToDateObject()
    {
        var i = 0;

        for(i=0; i < $scope.SamplesList.length; i++)
        {
            var date = $scope.SamplesList[i].CreatedAt;
            date = new Date(parseInt(date.substr(6)));
            date = $filter('date')(date, 'yyyy-MM-dd');
            $scope.SamplesList[i].CreatedAt = date;
        }
    }

    //create a sample, populate the date
    $scope.CreateSample = function()
    {
        //$scope.SampleObject.StatusId = 2;
        //$scope.SampleObject.CreatedBy =1
        $scope.SampleObject.CreatedAt = new Date();

        ftdnaService.CreateSample($scope.SampleObject).then(function (data, status) {
            
            $scope.success = "Sample Create Successfull";
            $scope.showSuccessAlert = true;

        }, function (data, status) {
            $scope.error = data.data.error;
            $scope.showErrorAlert = true;
        })

        //ftdnaService.CreateSample($scope.SampleObject).success(function(data, status){
            
        //    //dispaly bootstrap modal for success
        //    alert("no error");

        //}).error(function(data, status){
        //    alert("error");
        //    $scope.error = result.error;
        //})
    }

    $scope.ShowUserNameSearchFields = function()
    {
        $scope.showUserNameSearch = true;
        $scope.showStatusSearch = false;
        $scope.showCreateSample = false;
        $scope.showSampleTable = false;

        $scope.showErrorAlert = false;
        $scope.showSuccessAlert = false;

        $scope.SamplesList = [];
    }

    $scope.ShowStatusSearchFields = function ()
    {
        $scope.showStatusSearch = true;
        $scope.showUserNameSearch = false;
        $scope.showCreateSample = false;
        $scope.showSampleTable = false;

        $scope.showErrorAlert = false;
        $scope.showSuccessAlert = false;

        $scope.SamplesList = [];
    }

    $scope.ShowCreateSampleFields = function()
    {
        $scope.showCreateSample = true;
        $scope.showStatusSearch = false;
        $scope.showUserNameSearch = false;
        $scope.showSampleTable = false;
        $scope.SamplesList = [];
    }

}]);