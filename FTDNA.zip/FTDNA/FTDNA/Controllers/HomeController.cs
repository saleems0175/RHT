﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web;
using System.Web.Mvc;
using Data.Repositories;
using Data.Models;

namespace FTDNA.Controllers
{
    public class HomeController : Controller
    {
        private ISampleRepostitory sampleRepository;
        private IUserRepository userRepository;
        private IStatusRepository statusRepository;
        // GET: Home

        public HomeController()
        {
            sampleRepository = new SampleRepository();
            userRepository = new UserRepository();
            statusRepository = new StatusRepository();
        }
        public ActionResult Index()
        {
            //get list of Users
            var userList = userRepository.GetAllUsers();

            //get list of Statuses
            var statusList = statusRepository.GetAllStatuses();

            ViewBag.userList = userList.ToDictionary(u => u.UserId, u => u.FirstName + " " + u.LastName);
            //ViewBag.statusList = statusList.Select(s  => s.StatusDescription).ToList
            ViewBag.statusList = statusList.ToDictionary(s => s.StatusId, s => s.StatusDescription);
          
            return View();
        }

        public JsonResult GetAllSamples()
        {
            var samplesList = sampleRepository.GetAllSamples();

            return Json(samplesList);
        }

        public JsonResult GetSampleByUserNameSearch(string userNameSearchString)
        {
            var sampleList = sampleRepository.GetSampleByUserNameSearch(userNameSearchString);
            return Json(sampleList);
        }

        public JsonResult GetSamplesByStatusSearch(string statusDescription)
        {
            var sampleList = sampleRepository.GetSamplesByStatusSearch(statusDescription);
            return Json(sampleList);
        }

        public JsonResult CreateSample(Sample sample)
        {
            try
            {
                if (ModelState.IsValid)
                {
                    sampleRepository.Add(sample);
                    return Json(new { success = true, status = HttpStatusCode.OK });
                }
                else
                {
                    Response.StatusCode = (int)HttpStatusCode.InternalServerError;
                    return Json(new { sucess = false, error = "Model State Validation failed" });
                }
            }
            catch (Exception ex)
            {
                Response.StatusCode = (int)HttpStatusCode.InternalServerError;
                return Json(new { sucess = false, error = ex.Message });
            }
        }

    }
}