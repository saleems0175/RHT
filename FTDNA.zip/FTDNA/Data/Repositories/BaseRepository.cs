﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Data.Repositories
{
    public interface IBaseRepository
    {
        void LoadData();
    }
    public class BaseRepository : IBaseRepository
    {
        protected FTDNAContext context;
        protected string filePath;

        public BaseRepository(string fileName)
        {
            context = new FTDNAContext();
            var root = AppDomain.CurrentDomain.BaseDirectory;
            filePath = root + fileName;
        }

        public virtual void LoadData() { }
    }
}
